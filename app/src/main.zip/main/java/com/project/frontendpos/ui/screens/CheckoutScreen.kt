package com.project.frontendpos.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import com.project.frontendpos.ui.components.CartItemCard
import com.project.frontendpos.viewmodel.CartViewModel
import com.project.frontendpos.viewmodel.CheckoutUiState
import com.project.frontendpos.viewmodel.CheckoutViewModel

@Composable
fun CheckoutScreen(
    navController: NavController,
    cartViewModel: CartViewModel,
    checkoutViewModel: CheckoutViewModel = viewModel()
) {

    val cart by cartViewModel.cart.collectAsState()
    val state = checkoutViewModel.uiState.value

    var paymentMethod by remember {
        mutableStateOf("cash")
    }

    LaunchedEffect(state) {
        if (state is CheckoutUiState.Success) {

            cartViewModel.clear()

            checkoutViewModel.resetState()

            navController.popBackStack()
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {

        Text(
            "Checkout",
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold
        )

        Spacer(Modifier.height(16.dp))

        Text(
            "Items",
            style = MaterialTheme.typography.titleMedium
        )

        Spacer(Modifier.height(8.dp))

        LazyColumn(
            modifier = Modifier.weight(1f)
        ) {

            items(cart.items) { item ->

                CartItemCard(
                    item = item
                )
            }
        }

        Spacer(Modifier.height(16.dp))

        Text(
            "Payment Method",
            style = MaterialTheme.typography.titleMedium
        )

        Row {

            RadioButton(
                selected = paymentMethod == "cash",
                onClick = {
                    paymentMethod = "cash"
                }
            )

            Text("Cash")

            Spacer(Modifier.width(16.dp))

            RadioButton(
                selected = paymentMethod == "qris",
                onClick = {
                    paymentMethod = "qris"
                }
            )

            Text("QRIS")

        }

        Spacer(Modifier.height(16.dp))

        Text("Subtotal : Rp ${cartViewModel.subtotal}")
        Text("Tax : Rp ${cartViewModel.tax}")
        Text("Total : Rp ${cartViewModel.total}")

        Spacer(Modifier.height(24.dp))

        Button(
            modifier = Modifier.fillMaxWidth(),
            enabled = state !is CheckoutUiState.Loading,
            onClick = {

                checkoutViewModel.checkout(
                    cart.items,
                    paymentMethod
                )

            }
        ) {

            if (state is CheckoutUiState.Loading) {

                CircularProgressIndicator(
                    modifier = Modifier.size(20.dp)
                )

            } else {

                Text("Confirm Payment")

            }

        }

        if (state is CheckoutUiState.Error) {

            Spacer(Modifier.height(8.dp))

            Text(
                state.message,
                color = MaterialTheme.colorScheme.error
            )

        }

    }

}